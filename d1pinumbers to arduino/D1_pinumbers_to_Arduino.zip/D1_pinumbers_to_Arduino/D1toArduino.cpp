#include "D1toArduino.h"
#include "Arduino.h"

d1toarduino::d1toarduino() {
  int pin2 = 26;
  int pin3 = 25;
  int pin4 = 17;
  int pin5 = 16;
  int pin6 = 27;
  int pin7 = 14;
  int pin8 = 12;
  int pin9 = 13;
  int pin10 = 5;
  int pin11 = 23;
  int pin12 = 19;
  int pin13 = 18;
}