#ifndef D1TOARDUINO_H
#define D1TOARDUINO_H

class d1toarduino {

public:
 d1toarduino();
 void setnumbers();
 
 private:
 
};

#endif